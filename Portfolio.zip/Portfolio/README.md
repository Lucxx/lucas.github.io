# Roadmap du Portfolio : Lucas SONG

Ce document présente l'analyse fonctionnelle de mon portfolio professionnel, détaillant les solutions techniques implémentées en **Phase 1 (V1.0)** et les axes de développement pour la **Phase 2 (V2.0)**.



## Version 1.0 : État Actuel de la Solution
La première version se concentre sur une interface utilisateur (UI) performante et une navigation fluide, uniquement en html et css.

### Navigation & Interactivité
* **Navigation par Ancres Fluides** : Mise en place de liens internes (`href="#id"`) permettant un accès direct aux sections "À Propos", "Parcours", "Compétences" etc.
* **Maillage Externe Professionnel** : Intégration de connecteurs directs vers mes profils **LinkedIn** et **GitLab**.
* **Formulaire avec Contrôle de Saisie** : Utilisation des attributs HTML5 (`required`, `type="email"`) pour valider l'intégrité des données avant l'envoi.
* **Feedback Visuel (Hover Effects)** : Dynamisation de l'expérience utilisateur via des propriétés CSS (`transform`, `box-shadow`) sur les cartes et les boutons.

### Structure & Identité Visuelle
* **Architecture "Dual-Pane"** : Structure asymétrique séparant une barre latérale fixe (`sidebar`) d'une zone de contenu dynamique (`main-content`).
* **Grid Layout Responsive** : Organisation optimisée des données en grilles adaptatives (3 colonnes pour le parcours, 4 pour les compétences).
* **Design Dark Mode & Néon** : Charte graphique moderne basée sur un fond sombre (`#0a0a0c`) et une couleur d'accentuation rouge néon (`#ff0000`).



## Version 2.0 : Évolutions & Optimisations
La prochaine itération visera à transformer cette vitrine statique en un outil interactif complet.

### Améliorations Techniques
* **Dynamisation du Formulaire** : Mettre en place l'interface du formulaire en php avec un service d'envoi de courriels pour rendre la prise de contact opérationnelle.
* **Fonction de Téléchargement** : Implémentation de l'attribut `download` sur un bouton dédié pour permettre la récupération du CV au format PDF.
* **Standardisation des Assets** : Migration des émojis vers une bibliothèque d'icônes vectorielles locales pour une esthétique plus rigoureuse.

###  Enrichissement du Contenu Professionnel
* **Module de Veille Technologique** : Création d'une section documentant la méthodologie, les outils de curation et les thématiques SIO suivies.
* **Section projets** : Mise en place des projets dans la section "Projets" une fois qu'ils seront terminés.
* **Galerie de Projets (E4)** : Évolution de la section Projets vers une galerie interactive présentant les réalisations majeures avec liens vers les dépôts GitLab.
* **Data Visualization des Compétences** : Intégration de barres de progression animées pour quantifier le niveau de maîtrise des différents langages (PHP, Python, Java etc).
* **Story telling** : Ajouter des parties où je raconte mon histoire (qu'est-ce qui me plaît, pourquoi avoir choisi cela, mes ambitions etc).